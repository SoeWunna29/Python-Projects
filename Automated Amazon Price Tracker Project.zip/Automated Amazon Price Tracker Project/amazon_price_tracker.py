import requests
from bs4 import BeautifulSoup
import lxml
import smtplib

# Getting Product Price from Amazon
url = "https://www.amazon.com/God-War-Playstation-4/dp/B01GW8XOY2"

header = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9"
}

response = requests.get(url, headers=header)

soup = BeautifulSoup(response.content, "lxml")
# print(soup.prettify())

price = soup.find(id="priceblock_pospromoprice").get_text()
print(price)
price_without_currency = price.split("$")[1]
price_as_float = float(price_without_currency)
print(price_as_float)

# Sending Price Alert Email
title = soup.find(id="productTitle").get_text().strip()
print(title)

BUY_PRICE = 20
MY_EMAIL = "kratosgodofwarzeuspython123@gmail.com"
MY_PASSWORD = "Pas$w0rd"

if price_as_float < BUY_PRICE:
    message = f"{title} is now {price}"

    with smtplib.SMTP("smtp.gmail.com", port=587) as connection:
        connection.starttls()
        result = connection.login(MY_EMAIL, MY_PASSWORD)
        connection.sendmail(
            from_addr=MY_EMAIL,
            to_addrs="mrsoewunna1996@gmail.com",
            msg=f"Subject:Amazon Price Alert!\n\n{message}\n{url}"
        )
