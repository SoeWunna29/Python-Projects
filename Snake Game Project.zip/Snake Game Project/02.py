piano_keys = ["a", "b", "c", "d", "e", "f", "g"]
piano_tuple = ("a", "b", "c", "d", "e", "f", "g")

print(piano_keys[2:5])
print(piano_keys[2:])
print(piano_keys[:5])
print(piano_keys[2:7:2])
print(piano_keys[::-1])

print(piano_tuple[2:5])
print(piano_tuple[2:])
print(piano_tuple[:5])
print(piano_tuple[2:7:2])
print(piano_tuple[::-1])
